import asyncio
import logging
import time
from datetime import datetime
import requests

from web3 import Web3
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler

import config

# Setup logging
logger = logging.getLogger("meu-bot-usdt")
logger.setLevel(logging.INFO)
fh = logging.FileHandler("logs/bot.log")
fh.setLevel(logging.INFO)
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
fh.setFormatter(formatter)
logger.addHandler(fh)
logger.info("Logger iniciado")

# Initialize Web3
w3 = Web3(Web3.HTTPProvider(config.INFURA_URL))
if not w3.isConnected():
    logger.warning("Não conectado ao RPC ainda.")

# ABI mínimo para ERC20 (balanceOf + transfer)
ABI_ERC20 = [
    {
        "constant": False,
        "inputs": [
            {"name": "_to", "type": "address"},
            {"name": "_value", "type": "uint256"},
        ],
        "name": "transfer",
        "outputs": [{"name": "", "type": "bool"}],
        "type": "function",
    },
    {
        "constant": True,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "type": "function",
    },
]

USDT_CONTRACT = w3.toChecksumAddress(config.USDT_CONTRACT)
contract = w3.eth.contract(address=USDT_CONTRACT, abi=ABI_ERC20)

CHAT_IDS = config.CHAT_IDS

# Helper: send message to all configured chat ids
def send_telegram_message(message: str):
    token = config.TELEGRAM_TOKEN
    if not token:
        logger.error("TELEGRAM_TOKEN não configurado.")
        return
    for chat_id in CHAT_IDS:
        try:
            resp = requests.post(f"https://api.telegram.org/bot{token}/sendMessage", data={"chat_id": chat_id, "text": message})
            if resp.status_code != 200:
                logger.warning(f"Telegram send failed: {resp.status_code} {resp.text}")
        except Exception as e:
            logger.exception("Erro ao enviar mensagem Telegram")

def conectar_w3():
    w3_local = Web3(Web3.HTTPProvider(config.INFURA_URL))
    if not w3_local.isConnected():
        raise Exception("❌ Não conectou ao RPC Infura.")
    return w3_local

def transfer_usdt(valor, origem, private_key):
    try:
        w3_local = conectar_w3()
        contract_local = w3_local.eth.contract(address=USDT_CONTRACT, abi=ABI_ERC20)

        amount_wei = int(valor * 10**6)
        nonce = w3_local.eth.get_transaction_count(origem, "pending")

        gas_estimate = contract_local.functions.transfer(config.WALLET_DESTINO, amount_wei).estimateGas({"from": origem})
        gas_limit = int(gas_estimate * 1.2)

        tx = contract_local.functions.transfer(config.WALLET_DESTINO, amount_wei).buildTransaction(
            {
                "chainId": 137,
                "gas": gas_limit,
                "gasPrice": w3_local.eth.gas_price,
                "nonce": nonce,
            }
        )

        signed_tx = w3_local.eth.account.sign_transaction(tx, private_key)
        tx_hash = w3_local.eth.send_raw_transaction(signed_tx.rawTransaction)

        msg = f"✅ USDT enviado!\n🔗 HASH: {w3_local.toHex(tx_hash)}"
        logger.info(msg)
        return msg

    except Exception as e:
        logger.exception("Erro na transferência")
        return f"❌ ERRO transferência: {e}"

def get_balances():
    w3_local = conectar_w3()
    contract_local = w3_local.eth.contract(address=USDT_CONTRACT, abi=ABI_ERC20)

    wallets = {
        "origem": w3_local.toChecksumAddress(config.WALLET_ORIGEM),
        "sa": w3_local.toChecksumAddress(config.WALLET_SA),
        "invest": w3_local.toChecksumAddress(config.WALLET_INVEST),
        "custos": w3_local.toChecksumAddress(config.WALLET_CUSTOS),
    }

    saldos = {}
    for nome, w in wallets.items():
        try:
            bal_raw = contract_local.functions.balanceOf(w).call()
            saldos[nome] = bal_raw / 10**6
        except Exception as e:
            logger.exception(f"Erro ao ler saldo {nome}")
            saldos[nome] = 0.0
    return saldos

# ================================
# COMANDOS (handlers)
# ================================
async def cmd_ro(update: Update, context):
    chat = str(update.effective_chat.id)
    if chat not in CHAT_IDS:
        return await update.message.reply_text("❌ Sem permissão.")

    try:
        valor = float(update.message.text.split()[1])
        saldos = get_balances()

        if saldos["origem"] < valor:
            return await update.message.reply_text(
                f"❌ Saldo insuficiente. Saldo: {saldos['origem']} USDT"
            )

        await update.message.reply_text("⏳ Enviando...")
        resp = transfer_usdt(valor, config.WALLET_ORIGEM, config.PRIVATE_KEY_ORIGEM)
        await update.message.reply_text(resp)

    except Exception as e:
        await update.message.reply_text(f"❌ ERRO: {e}")

async def cmd_sa(update: Update, context):
    chat = str(update.effective_chat.id)
    if chat not in CHAT_IDS:
        return await update.message.reply_text("❌ Sem permissão.")

    try:
        valor = float(update.message.text.split()[1])
        saldos = get_balances()

        if saldos["sa"] < valor:
            return await update.message.reply_text(
                f"❌ Saldo insuficiente. Saldo: {saldos['sa']} USDT"
            )

        await update.message.reply_text("⏳ Enviando...")
        resp = transfer_usdt(valor, config.WALLET_SA, config.PRIVATE_KEY_SA)
        await update.message.reply_text(resp)

    except Exception as e:
        await update.message.reply_text(f"❌ ERRO: {e}")

async def cmd_invest(update: Update, context):
    chat = str(update.effective_chat.id)
    if chat not in CHAT_IDS:
        return await update.message.reply_text("❌ Sem permissão.")

    try:
        valor = float(update.message.text.split()[1])
        saldos = get_balances()

        if saldos["invest"] < valor:
            return await update.message.reply_text(
                f"❌ Saldo insuficiente. Saldo: {saldos['invest']} USDT"
            )

        await update.message.reply_text("⏳ Enviando...")
        resp = transfer_usdt(valor, config.WALLET_INVEST, config.PRIVATE_KEY_INVEST)
        await update.message.reply_text(resp)

    except Exception as e:
        await update.message.reply_text(f"❌ ERRO: {e}")

async def cmd_custos(update: Update, context):
    chat = str(update.effective_chat.id)
    if chat not in CHAT_IDS:
        return await update.message.reply_text("❌ Sem permissão.")

    try:
        valor = float(update.message.text.split()[1])
        saldos = get_balances()

        if saldos["custos"] < valor:
            return await update.message.reply_text(
                f"❌ Saldo insuficiente. Saldo: {saldos['custos']} USDT"
            )

        await update.message.reply_text("⏳ Enviando...")
        resp = transfer_usdt(valor, config.WALLET_CUSTOS, config.PRIVATE_KEY_CUSTOS)
        await update.message.reply_text(resp)

    except Exception as e:
        await update.message.reply_text(f"❌ ERRO: {e}")

async def cmd_balance(update: Update, context):
    saldos = get_balances()

    msg = (
        "💰 *Saldos atuais:*\n"
        f"• Ro: {saldos['origem']:.2f}\n"
        f"• Sa: {saldos['sa']:.2f}\n"
        f"• Invest: {saldos['invest']:.2f}\n"
        f"• Custos: {saldos['custos']:.2f}"
    )

    await update.message.reply_text(msg, parse_mode="Markdown")

async def cmd_help(update: Update, context):
    await update.message.reply_text(
        "📌 Comandos:\n"
        "/ro <valor>\n"
        "/sa <valor>\n"
        "/invest <valor>\n"
        "/custos <valor>\n"
        "/balance\n"
        "/help"
    )

# ================================
# BACKGROUND TASKS: Heartbeat + Monitor
# ================================
async def heartbeat_task():
    while True:
        try:
            saldos = get_balances()
            msg = (f"🫀 Heartbeat — {datetime.utcnow().isoformat()}Z\n"
                   f"RPC connected: {w3.isConnected()}\n"
                   f"Balances: Ro={saldos['origem']:.2f}, Sa={saldos['sa']:.2f}, Invest={saldos['invest']:.2f}, Custos={saldos['custos']:.2f}")
            logger.info("Enviando heartbeat")
            send_telegram_message(msg)
        except Exception as e:
            logger.exception("Erro no heartbeat")
        await asyncio.sleep(config.HEARTBEAT_INTERVAL_SEC)

async def monitor_transfers_task():
    logger.info("Monitor de transfers iniciado")
    last_block = w3.eth.block_number
    # transfer topic
    transfer_topic = Web3.keccak(text='Transfer(address,address,uint256)').hex()
    logger.info(f"Transfer topic: {transfer_topic}")
    while True:
        try:
            current_block = w3.eth.block_number
            if current_block > last_block:
                from_block = last_block + 1
                to_block = current_block
                logger.info(f"Checking logs from {from_block} to {to_block}")
                try:
                    logs = w3.eth.get_logs({
                        'fromBlock': from_block,
                        'toBlock': to_block,
                        'address': USDT_CONTRACT,
                        'topics': [transfer_topic]
                    })
                except Exception as e:
                    logger.exception("Erro ao buscar logs")
                    logs = []

                for log in logs:
                    try:
                        # usar contract.events.Transfer para decodificar
                        ev = contract.events.Transfer().processLog(log)
                        frm = ev['args']['_from']
                        to = ev['args']['_to']
                        val = ev['args']['_value'] / 10**6
                        msg = f"🔔 Nova transferência USDT detectada: {val} USDT — from {frm} to {to} (block {log['blockNumber']})"
                        logger.info(msg)
                        send_telegram_message(msg)
                    except Exception as e:
                        logger.exception("Erro ao processar log")
                last_block = to_block
        except Exception as e:
            logger.exception("Erro no loop do monitor")
        await asyncio.sleep(config.POLL_INTERVAL_SEC)

# ================================
# MAIN
# ================================
def main():
    app = ApplicationBuilder().token(config.TELEGRAM_TOKEN).build()

    app.add_handler(CommandHandler("ro", cmd_ro))
    app.add_handler(CommandHandler("sa", cmd_sa))
    app.add_handler(CommandHandler("invest", cmd_invest))
    app.add_handler(CommandHandler("custos", cmd_custos))
    app.add_handler(CommandHandler("balance", cmd_balance))
    app.add_handler(CommandHandler("help", cmd_help))

    # Start background tasks after the bot starts polling
    async def run_background_tasks(app):
        await asyncio.gather(
            heartbeat_task(),
            monitor_transfers_task()
        )

    # Run the bot and background tasks
    async def _run():
        logger.info("Bot iniciando...")
        # create background tasks and run polling concurrently
        task_bg = asyncio.create_task(run_background_tasks(app))
        await app.initialize()
        await app.start()
        logger.info("Bot polling começando...")
        await app.updater.start_polling()
        # keep running
        await task_bg

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        logger.info("Bot finalizado pelo usuário")

if __name__ == "__main__":
    main()
