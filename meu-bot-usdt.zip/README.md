# Bot de Transferência USDT (Polygon)

Repositório gerado automaticamente. Estrutura:

```
meu-bot-usdt/
│
├── README.md
├── requirements.txt
├── .gitignore
├── .env.example
├── config.py
├── bot.py
└── logs/
```

## O que foi incluído
- Separação de configuração em `.env` (veja `.env.example`)
- `bot.py` com:
  - comandos Telegram (/ro, /sa, /invest, /custos, /balance, /help)
  - transferência USDT via contrato ERC20
  - monitoramento de novas transferências (polling)
  - heartbeat (status) enviado ao Telegram a cada 1 hora
  - logging em `logs/bot.log`
- `.gitignore` para evitar commit de chaves privadas e logs

## Instalação
1. Copie `.env.example` para `.env` e preencha valores sensíveis.
2. Crie e ative um virtualenv (recomendado).
3. Instale dependências:
   ```bash
   pip install -r requirements.txt
   ```
4. Rode:
   ```bash
   python bot.py
   ```

## Segurança
**NÃO** comite `.env` ou chaves privadas em repositórios públicos. Use variáveis de ambiente seguras.
