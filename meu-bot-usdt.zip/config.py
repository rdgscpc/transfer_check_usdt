import os
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_IDS = [cid.strip() for cid in os.getenv("CHAT_IDS", "").split(",") if cid.strip()]
INFURA_URL = os.getenv("INFURA_URL")
USDT_CONTRACT = os.getenv("USDT_CONTRACT")

WALLET_ORIGEM = os.getenv("WALLET_ORIGEM")
PRIVATE_KEY_ORIGEM = os.getenv("PRIVATE_KEY_ORIGEM")

WALLET_SA = os.getenv("WALLET_SA")
PRIVATE_KEY_SA = os.getenv("PRIVATE_KEY_SA")

WALLET_INVEST = os.getenv("WALLET_INVEST")
PRIVATE_KEY_INVEST = os.getenv("PRIVATE_KEY_INVEST")

WALLET_CUSTOS = os.getenv("WALLET_CUSTOS")
PRIVATE_KEY_CUSTOS = os.getenv("PRIVATE_KEY_CUSTOS")

WALLET_DESTINO = os.getenv("WALLET_DESTINO")

try:
    HEARTBEAT_INTERVAL_SEC = int(os.getenv("HEARTBEAT_INTERVAL_SEC", "3600"))
except:
    HEARTBEAT_INTERVAL_SEC = 3600

try:
    POLL_INTERVAL_SEC = int(os.getenv("POLL_INTERVAL_SEC", "15"))
except:
    POLL_INTERVAL_SEC = 15
